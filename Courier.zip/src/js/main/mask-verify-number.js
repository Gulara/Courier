$(document).ready(function () {
  $('#verify-number').mask('000000');
});