//  NEW FOR INDEX-3.HTML
$(document).ready(function() {
	$("#lightgallery").lightGallery({

		thumbnail:true,
		animateThumb: false,
		showThumbByDefault: false
	}); 

});