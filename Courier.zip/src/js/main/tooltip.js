$(document).ready(function () {
    $('.tooltip-circle').bind('hover focus', function() {
        $(".form__tooltip").find(".tooltip-inner").addClass("tooltip--inner") ;      
    });
	
});