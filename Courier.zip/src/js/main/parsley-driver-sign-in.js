//PARSLEY FOR  PEDESTRIAN FORM
$(document).ready(function () {

    $('#driver-form-pedestrian').parsley().on('field:validated', function () {
      var ok = $('.parsley-error').length === 0
  

    
    })
  
      .on('#driver-form-pedestrian:submit', function () {
        return false; // Don't submit form for this demo
      });
  
  });
// PARSLEY FOR OTHER DRIVERS
$(document).ready(function () {

    $('#driver-form').parsley().on('field:validated', function () {
      var ok = $('.parsley-error').length === 0
  

    
    })
  
      .on('#driver-form:submit', function () {
        return false; // Don't submit form for this demo
      });
  
  });
