// SCROLL FOR INDEX7

// $(document).ready(function () {

//     var $scrollheight = $('scrollbar1'),
//     scrollBottom = 490;

//     var $window = $(window),
//         previousScrollTop = 0,
//         scrollLock = true;

//     $window.scroll(function (event) {
     
//         if (scrollLock) {
//             $window.scrollTop(previousScrollTop);
//         }
//         previousScrollTop = $window.scrollTop();
//     });
   
  
//     $(".scrollbar1").scroll(function () {
//         if ( $scrollheight.scrollTop(scrollBottom)) {        
//             scrollLock = false;
//         } else {
//             scrollLock = true;
//         }
//     })

  
// });